package resume.resumeresuyou;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ResumeResuyouApplicationTests {

	@Test
	void contextLoads() {
	}

}
