package resume.resumeresuyou;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ResumeResuyouApplication {

	public static void main(String[] args) {
		SpringApplication.run(ResumeResuyouApplication.class, args);
	}

}
